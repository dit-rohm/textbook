function foo_func() {
  $("body, html").animate({
    scrollTop: 100
  });
}
