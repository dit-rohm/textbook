<?php
// init.php
